import pandas as pd
import pytest

from validator import validate_dataframe, ValidationError
from storage import save_dataset

def test_validation_accepts_symbol_column():
    frame = pd.DataFrame({"symbol": ["ABC"], "lastPrice": [100]})
    validate_dataframe(frame, "volume_gainers")

def test_validation_rejects_empty_dataframe():
    with pytest.raises(ValidationError):
        validate_dataframe(pd.DataFrame(), "volume_gainers")

def test_validation_rejects_missing_symbol():
    frame = pd.DataFrame({"company": ["ABC"]})
    with pytest.raises(ValidationError):
        validate_dataframe(frame, "volume_gainers")

def test_storage_removes_same_day_duplicates(tmp_path):
    frame = pd.DataFrame({"symbol": ["ABC", "ABC"], "lastPrice": [10, 11]})
    path = save_dataset(frame, "volume_gainers", tmp_path)
    saved = pd.read_csv(path)
    assert len(saved) == 1
    assert saved.iloc[0]["lastPrice"] == 11

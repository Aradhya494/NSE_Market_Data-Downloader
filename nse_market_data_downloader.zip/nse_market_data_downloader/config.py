from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
LOG_DIR = BASE_DIR / "logs"

NSE_HOME = "https://www.nseindia.com"
NSE_API = f"{NSE_HOME}/api/live-analysis-variations"

# These are public JSON endpoints used by the official NSE website.
# If NSE changes its website, update the index values here.
DATASETS = {
    "gainers_losers": {
        "filename": "top_gainers_losers.csv",
        "indices": ["gainers", "loosers"],
    },
    "upper_band": {
        "filename": "upper_band_hitters.csv",
        "indices": ["pricebandupper"],
    },
    "volume_gainers": {
        "filename": "volume_gainers.csv",
        "indices": ["volumeGainers"],
    },
    "52_week_high": {
        "filename": "52_week_high.csv",
        "indices": ["52WeekHigh"],
    },
}

REQUEST_TIMEOUT = 20
REQUEST_DELAY_SECONDS = 1.0

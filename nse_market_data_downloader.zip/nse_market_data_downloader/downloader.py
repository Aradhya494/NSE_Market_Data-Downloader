import logging
import time
from typing import Any

import pandas as pd
import requests

from config import NSE_HOME, NSE_API, DATASETS, REQUEST_TIMEOUT, REQUEST_DELAY_SECONDS

class DownloadError(Exception):
    """Raised when NSE data cannot be downloaded or decoded."""

class NSEDownloader:
    def __init__(self, timeout: int = REQUEST_TIMEOUT):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/128.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": NSE_HOME + "/",
            "Connection": "keep-alive",
        })

    def _warm_up_session(self) -> None:
        """Visit the official NSE homepage first so the session can receive cookies."""
        try:
            response = self.session.get(NSE_HOME, timeout=self.timeout)
            response.raise_for_status()
        except requests.Timeout as exc:
            raise DownloadError("NSE homepage request timed out. Try again later.") from exc
        except requests.RequestException as exc:
            raise DownloadError(f"Could not connect to NSE website: {exc}") from exc

    @staticmethod
    def _extract_records(payload: Any) -> list[dict]:
        """Handle the common NSE JSON response shapes."""
        if isinstance(payload, list):
            records = payload
        elif isinstance(payload, dict):
            records = payload.get("data")
            if records is None:
                # Some responses wrap data one level deeper.
                records = payload.get("grids") or payload.get("records")
            if isinstance(records, dict):
                records = records.get("data") or records.get("records")
        else:
            records = None

        if not isinstance(records, list):
            raise DownloadError("NSE response did not contain a list of records.")
        return [row for row in records if isinstance(row, dict)]

    def _fetch_index(self, index_name: str) -> pd.DataFrame:
        url = NSE_API
        try:
            response = self.session.get(
                url,
                params={"index": index_name},
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.Timeout as exc:
            raise DownloadError(f"Request timed out for '{index_name}'.") from exc
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            raise DownloadError(f"NSE returned HTTP status {status} for '{index_name}'.") from exc
        except requests.RequestException as exc:
            raise DownloadError(f"Network error for '{index_name}': {exc}") from exc

        try:
            payload = response.json()
        except ValueError as exc:
            raise DownloadError(
                f"NSE did not return valid JSON for '{index_name}'. "
                "The website may be blocking the request or its response format may have changed."
            ) from exc

        records = self._extract_records(payload)
        if not records:
            raise DownloadError(
                f"No records were returned for '{index_name}'. "
                "The market may be closed, the dataset may be empty, or NSE may have changed its API."
            )
        return pd.DataFrame(records)

    def download(self, dataset_name: str) -> pd.DataFrame:
        if dataset_name not in DATASETS:
            raise ValueError(f"Unknown dataset: {dataset_name}")

        self._warm_up_session()
        frames = []
        for index_name in DATASETS[dataset_name]["indices"]:
            frame = self._fetch_index(index_name)
            if dataset_name == "gainers_losers":
                category = "gainers" if index_name == "gainers" else "losers"
                frame["category"] = category
            frames.append(frame)
            time.sleep(REQUEST_DELAY_SECONDS)

        result = pd.concat(frames, ignore_index=True, sort=False)
        logging.info("Fetched %s row(s) for %s", len(result), dataset_name)
        return result
